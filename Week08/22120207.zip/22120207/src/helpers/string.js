export const formatPrice = (price) => {
  return `${price.toString().replace(".", ",")} ₫`;
};
