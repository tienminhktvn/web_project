export const getImgSrc = (id) => {
  return `assets/p${id}.png`;
};
