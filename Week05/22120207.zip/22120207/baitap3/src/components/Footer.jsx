const Footer = () => {
  return (
    <div className="text-center bg-[#dedfe1] p-3 rounded-md pb-6">
      Footer content goes here
    </div>
  );
};

export default Footer;
