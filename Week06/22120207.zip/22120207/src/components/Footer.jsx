const Footer = () => {
  return (
    <div className="text-center bg-[#f8f9fa] rounded-sm p-5">
      ⓒ 2025 Minh Company
    </div>
  );
};

export default Footer;
